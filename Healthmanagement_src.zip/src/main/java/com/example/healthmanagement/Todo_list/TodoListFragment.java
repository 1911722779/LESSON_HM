package com.example.healthmanagement.Todo_list;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthmanagement.R;

import java.util.ArrayList;
import java.util.List;

public class TodoListFragment extends Fragment {

    private EditText editTextTask;
    private Button buttonAddTask;
    private RecyclerView recyclerViewTasks;
    private List<Task> taskList;
    private TaskAdapter taskAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.todo_list, container, false);

        editTextTask = view.findViewById(R.id.edit_text_task);
        buttonAddTask = view.findViewById(R.id.button_add_task);
        recyclerViewTasks = view.findViewById(R.id.recycler_view_tasks);

        taskList = new ArrayList<>();
        taskAdapter = new TaskAdapter(taskList);
        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewTasks.setAdapter(taskAdapter);

        buttonAddTask.setOnClickListener(v -> {
            String taskText = editTextTask.getText().toString().trim();
            if (!taskText.isEmpty()) {
                taskList.add(new Task(taskText));
                taskAdapter.notifyItemInserted(taskList.size() - 1);
                editTextTask.setText("");
            }
        });

        return view;
    }
}
