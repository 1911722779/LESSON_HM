package com.example.healthmanagement.Todo_list;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthmanagement.R;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private List<Task> taskList;

    public TaskAdapter(List<Task> taskList) {
        this.taskList = taskList;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.todo_list_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.bind(task);

        holder.buttonComplete.setOnClickListener(v -> {
            task.setCompleted(true);
            holder.textViewTask.setPaintFlags(holder.textViewTask.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        });

        holder.buttonCancel.setOnClickListener(v -> {
            taskList.remove(position);
            notifyItemRemoved(position);
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView textViewTask;
        Button buttonComplete;
        Button buttonCancel;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTask = itemView.findViewById(R.id.text_view_task);
            buttonComplete = itemView.findViewById(R.id.button_complete);
            buttonCancel = itemView.findViewById(R.id.button_cancel);
        }

        public void bind(Task task) {
            textViewTask.setText(task.getTask());
            if (task.isCompleted()) {
                textViewTask.setPaintFlags(textViewTask.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            } else {
                textViewTask.setPaintFlags(0);
            }
        }
    }
}
