package com.example.healthmanagement;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HealthReportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_report);

        TextView tvReport = findViewById(R.id.tv_report_content);

        // 从 Intent 中获取传来的数据
        double height = getIntent().getDoubleExtra("height", 0);
        double weight = getIntent().getDoubleExtra("weight", 0);
        int systolic = getIntent().getIntExtra("systolic", 0);
        int diastolic = getIntent().getIntExtra("diastolic", 0);
        double bloodSugar = getIntent().getDoubleExtra("blood_sugar", 0.0);

        // 计算 BMI
        double bmi = weight / Math.pow(height / 100, 2);

        // 判断各项是否正常
        boolean isBpNormal = systolic >= 90 && systolic <= 140 &&
                diastolic >= 60 && diastolic <= 90;
        boolean isSugarNormal = bloodSugar >= 3.9 && bloodSugar <= 6.1;

        // 构建富文本内容
        String report = "<h2>📌 基本信息</h2>" +
                "<ul>" +
                "<li>身高：" + height + " cm</li>" +
                "<li>体重：" + weight + " kg</li>" +
                "<li>BMI：" + String.format("%.1f", bmi) + "</li>" +
                "</ul>" +

                "<h2>🫀 血压情况</h2>" +
                "<ul>" +
                "<li>收缩压：" + systolic + " mmHg</li>" +
                "<li>舒张压：" + diastolic + " mmHg</li>" +
                "</ul>" +

                "<h2>💉 血糖水平</h2>" +
                "<ul>" +
                "<li>空腹血糖：" + String.format("%.1f", bloodSugar) + " mmol/L</li>" +
                "</ul>";

        if (isBpNormal && isSugarNormal) {
            report += "<p style='color:green;'>✅ 您的身体状况良好，请继续保持健康生活习惯。</p>";
        } else {
            report += "<p style='color:red;'>⚠️ 您有指标超出正常范围，请注意饮食与运动。</p>";
        }

        // 使用 HTML 解析显示富文本
        tvReport.setText(android.text.Html.fromHtml(report, android.text.Html.FROM_HTML_MODE_LEGACY));
    }
}