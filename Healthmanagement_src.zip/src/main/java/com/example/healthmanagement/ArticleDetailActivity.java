package com.example.healthmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthmanagement.R;
import com.example.healthmanagement.Bean.Article;
import com.example.healthmanagement.Data.ArticleDatabaseHelper;

public class ArticleDetailActivity extends AppCompatActivity {

    private TextView tvTitle, tvAuthor, tvLikes, tvCollect, tvContent;
    private Button btnLike, btnCollect;
    private Article article;
    private boolean hasLiked = false;  // 是否已经点赞过

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_detail);

        // 初始化控件
        tvTitle = findViewById(R.id.tv_detail_title);
        tvAuthor = findViewById(R.id.tv_detail_author);
        tvLikes = findViewById(R.id.tv_detail_likes);
        tvCollect = findViewById(R.id.tv_detail_collect);
        tvContent = findViewById(R.id.tv_detail_content);
        btnLike = findViewById(R.id.btn_like);
        btnCollect = findViewById(R.id.btn_collect);

        // 获取传入的文章对象
        article = (Article) getIntent().getSerializableExtra("article");

        // 获取传递过来的文章对象
        if (getIntent().hasExtra("article")) {
            Article article = (Article) getIntent().getSerializableExtra("article");
            tvTitle.setText(article.getTitle());
            tvAuthor.setText("作者：" + article.getAuthor());
            tvContent.setText(article.getContent());
        }

        // 点赞按钮点击事件
        btnLike.setOnClickListener(v -> {
            if (!hasLiked) {
                int newLikes = article.getLikes() + 1;
                article.setLikes(newLikes);
                hasLiked = true;
                tvLikes.setText("点赞数：" + newLikes);
                Toast.makeText(this, "感谢点赞！", Toast.LENGTH_SHORT).show();

                // 更新数据库中的 likes 字段（可选）
                new ArticleDatabaseHelper().updateArticleLikes(article.getId(), newLikes);
            } else {
                Toast.makeText(this, "您已经点过赞了", Toast.LENGTH_SHORT).show();
            }
        });

        // 收藏按钮点击事件
        btnCollect.setOnClickListener(v -> {
            boolean isCollectedNow = !article.isCollect();
            article.setCollect(isCollectedNow);
            tvCollect.setText("是否收藏：" + (isCollectedNow ? "是" : "否"));
            btnCollect.setText(isCollectedNow ? "⭐ 已收藏" : "⭐ 未收藏");
            Toast.makeText(this, isCollectedNow ? "已收藏" : "已取消收藏", Toast.LENGTH_SHORT).show();

            // 更新数据库中的 isCollect 字段
            new ArticleDatabaseHelper().updateArticleCollectStatus(article.getId(), isCollectedNow);
        });
    }

    private void updateUI() {
        tvTitle.setText(article.getTitle());
        tvAuthor.setText("作者：" + article.getAuthor());
        tvLikes.setText("点赞数：" + article.getLikes());
        tvCollect.setText("是否收藏：" + (article.isCollect() ? "是" : "否"));
        tvContent.setText("内容：\n" + article.getContent());

        btnCollect.setText(article.isCollect() ? "⭐ 已收藏" : "⭐ 未收藏");
    }
}