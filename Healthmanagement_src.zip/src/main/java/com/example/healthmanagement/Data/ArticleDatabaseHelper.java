package com.example.healthmanagement.Data;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.example.healthmanagement.Bean.Article;
import com.example.healthmanagement.Fragment.HomeFragment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ArticleDatabaseHelper {
    private Context context;
    private static final String DB_URL = "jdbc:mysql://192.168.129.87:3306/health_db?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "cn";
    private static final String DB_PASSWORD = "123456";

    public interface OnDataLoadedListener {
        void onDataLoaded(List<Article> articles);
    }

//    public ArticleDatabaseHelper(Context context) {
//        this.context = context;
//        // 可以在这里初始化数据库连接等操作
//    }

    // 获取所有文章
    public void getAllArticles(OnDataLoadedListener listener) {
        new GetAllArticlesTask(listener).execute();
    }

    // 搜索文章（标题或作者）
    public void searchArticles(String query, OnDataLoadedListener listener) {
        new SearchArticlesTask(query, listener).execute();
    }

    // AsyncTask：获取所有文章
    private static class GetAllArticlesTask extends AsyncTask<Void, Void, List<Article>> {
        private final OnDataLoadedListener listener;

        private GetAllArticlesTask(OnDataLoadedListener listener) {
            this.listener = listener;
        }

        @Override
        protected List<Article> doInBackground(Void... voids) {
            List<Article> articles = new ArrayList<>();
            try {
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM article");
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    articles.add(new Article(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("author"),
                            rs.getInt("likes"),
                            rs.getBoolean("isCollect"),
                            rs.getString("content")  // 新增这一行
                    ));
                }

                rs.close();
                stmt.close();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return articles;
        }

        @Override
        protected void onPostExecute(List<Article> articles) {
            if (listener != null) {
                listener.onDataLoaded(articles);
            }
        }
    }

    // AsyncTask：搜索文章
    private static class SearchArticlesTask extends AsyncTask<Void, Void, List<Article>> {
        private final String query;
        private final OnDataLoadedListener listener;

        private SearchArticlesTask(String query, OnDataLoadedListener listener) {
            this.query = "%" + query + "%";
            this.listener = listener;
        }

        @Override
        protected List<Article> doInBackground(Void... voids) {
            List<Article> articles = new ArrayList<>();
            try {
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                PreparedStatement stmt = conn.prepareStatement(
                        "SELECT * FROM article WHERE title LIKE ? OR author LIKE ?");
                stmt.setString(1, query);
                stmt.setString(2, query);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    articles.add(new Article(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("author"),
                            rs.getInt("likes"),
                            rs.getBoolean("isCollect"),
                            rs.getString("content")  // 新增这一行
                    ));
                }

                rs.close();
                stmt.close();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return articles;
        }

        @Override
        protected void onPostExecute(List<Article> articles) {
            if (listener != null) {
                listener.onDataLoaded(articles);
            }
        }
    }
    // 更新点赞数
    public void updateArticleLikes(int id, int newLikesCount) {
        new UpdateLikesTask(id, newLikesCount).execute();
    }

    private static class UpdateLikesTask extends AsyncTask<Void, Void, Boolean> {
        private final int id;
        private final int likes;

        public UpdateLikesTask(int id, int likes) {
            this.id = id;
            this.likes = likes;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            try {
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE article SET likes = ? WHERE id = ?");
                stmt.setInt(1, likes);
                stmt.setInt(2, id);
                int rowsAffected = stmt.executeUpdate();
                stmt.close();
                conn.close();
                return rowsAffected > 0;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (!success) {

            }
        }
    }

    // 更新收藏状态
    public void updateArticleCollectStatus(int id, boolean isCollected) {
        new UpdateCollectTask(id, isCollected).execute();
    }

    private static class UpdateCollectTask extends AsyncTask<Void, Void, Boolean> {
        private final int id;
        private final boolean isCollected;

        public UpdateCollectTask(int id, boolean isCollected) {
            this.id = id;
            this.isCollected = isCollected;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            try {
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE article SET isCollect = ? WHERE id = ?");
                stmt.setBoolean(1, isCollected);
                stmt.setInt(2, id);
                int rowsAffected = stmt.executeUpdate();
                stmt.close();
                conn.close();
                return rowsAffected > 0;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (!success) {

            }
        }
    }

    // 获取收藏文章
    public List<Article> getCollectedArticles() {
        return new QueryCollectionTask().doInBackground();
    }

    private static class QueryCollectionTask extends AsyncTask<Void, Void, List<Article>> {

        @Override
        protected List<Article> doInBackground(Void... voids) {
            try {
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM article WHERE isCollect = TRUE");

                List<Article> collectedList = new ArrayList<>();
                while (rs.next()) {
                    collectedList.add(new Article(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("author"),
                            rs.getInt("likes"),
                            rs.getBoolean("isCollect"),
                            rs.getString("content")
                    ));
                }

                rs.close();
                stmt.close();
                conn.close();

                return collectedList;
            } catch (Exception e) {
                e.printStackTrace();
                return new ArrayList<>();
            }
        }
    }

    // 更新收藏数
    public int getCollectedArticleCount() {
        return new QueryCollectionCountTask().doInBackground();
    }

    private static class QueryCollectionCountTask extends AsyncTask<Void, Void, Integer> {
        @Override
        protected Integer doInBackground(Void... voids) {
            try {
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM article WHERE isCollect = TRUE");
                if (rs.next()) {
                    return rs.getInt(1);
                }
                rs.close();
                stmt.close();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }
    }
}