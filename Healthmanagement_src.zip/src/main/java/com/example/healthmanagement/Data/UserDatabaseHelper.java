package com.example.healthmanagement.Data;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDatabaseHelper {

    // 数据库连接信息
    private static final String DB_URL = "jdbc:mysql://192.168.129.87:3306/health_db?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "cn";
    private static final String DB_PASSWORD = "123456";
    private Context context;

    public UserDatabaseHelper(Context context) {
        this.context = context;
    }
    /**
     * 测试数据库连接
     */
    public void testDatabaseConnection() {
        Connection connection = null;
        try {
            // 注册 JDBC 驱动程序（对于较新的 JDBC 版本可能不需要）
            Class.forName("com.mysql.jdbc.Driver");

            // 打开连接
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // 如果连接成功，显示 Toast 消息
            if (connection != null) {
                ((android.app.Activity)context).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(context, "数据库连接成功", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } catch (SQLException | ClassNotFoundException e) {
            // 处理异常情况
            e.printStackTrace();

            // 在 UI 线程上显示错误消息
            ((android.app.Activity)context).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(context, "数据库连接失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        } finally {
            // 关闭连接
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public boolean checkUser(String phone, String password) {
        boolean isValid = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String sql = "SELECT * FROM users WHERE phone = ? AND password = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, phone);
            stmt.setString(2, password);

            rs = stmt.executeQuery();
            if (rs.next()) {
                isValid = true; // 账号密码正确
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 关闭连接
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return isValid;
    }
    /**
     * 注册用户（插入数据）将用户输入的数据（如用户id、手机号、密码、姓名等）传递给一个异步任务 RegisterUserTask 来在后台执行数据库插入操作
     */
    public void registerUser(Context context, String phone, String password, String name,
                             int age, float height, float weight, String gender) {
        new RegisterUserTask(context)
                .execute(phone, password, name,
                        String.valueOf(age),
                        String.valueOf(height),
                        String.valueOf(weight),
                        gender);
        Log.d("DB_DEBUG", "URL: " + DB_URL);
        Log.d("DB_DEBUG", "USER: " + DB_USER);
        Log.d("DB_DEBUG", "PASS: " + DB_PASSWORD);

    }

    // ──────────────── AsyncTask 实现部分 ────────────────

    /**
     * 插入用户任务
     */
    private static class RegisterUserTask extends android.os.AsyncTask<String, Void, Boolean> {

        private Context context;
        private Exception exception;

        public RegisterUserTask(Context context) {
            this.context = context.getApplicationContext();
        }

        @Override
        protected Boolean doInBackground(String... params) {
            // 将传入的字符串参数分别赋值给对应的变量
            String phone = params[0];
            String password = params[1];
            String name = params[2];
            int age = Integer.parseInt(params[3]);
            float height = Float.parseFloat(params[4]);
            float weight = Float.parseFloat(params[5]);
            String gender = params[6];

            Connection connection = null;
            PreparedStatement statement = null;

            try {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                // 插入数据的 SQL 语句
                String sql = "INSERT INTO users (phone, password, name, age, height, weight, gender) VALUES (?, ?, ?, ?, ?, ?, ?)";
                // 设置参数并执行插入操作
                statement = connection.prepareStatement(sql);
                statement.setString(1, phone);
                statement.setString(2, password);
                statement.setString(3, name);
                statement.setInt(4, age);
                statement.setFloat(5, height);
                statement.setFloat(6, weight);
                statement.setString(7, gender);

                int rowsInserted = statement.executeUpdate();
                return rowsInserted > 0;

            } catch (Exception e) {
                exception = e;
                Log.e("RegisterUserTask", "数据库错误", e);
                return false;
            } finally {
                closeResources(connection, statement);
            }
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Toast.makeText(context, "注册成功！", Toast.LENGTH_SHORT).show();
            } else {
                String errorMsg = exception != null ? exception.getMessage() : "未知错误";
                Toast.makeText(context, "注册失败：" + errorMsg, Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * 更新用户信息任务
     */
    public static class UpdateUserTask extends AsyncTask<String, Void, Boolean> {

        private Context context;

        public UpdateUserTask(Context context) {
            this.context = context.getApplicationContext();
        }

        @Override
        protected Boolean doInBackground(String... params) {
            String phone = params[0];
            String password = params[1];
            String name = params[2];
            String ageStr = params[3];
            String heightStr = params[4];
            String weightStr = params[5];
            String gender = params[6];

            int age = Integer.parseInt(ageStr);
            float height = Float.parseFloat(heightStr);
            float weight = Float.parseFloat(weightStr);

            Connection connection = null;
            PreparedStatement checkStmt = null;
            PreparedStatement updateStmt = null;
            ResultSet resultSet = null;

            try {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

                // 步骤一：先检查用户是否存在
                String checkSql = "SELECT * FROM users WHERE phone=?";
                checkStmt = connection.prepareStatement(checkSql);
                checkStmt.setString(1, phone);
                resultSet = checkStmt.executeQuery();

                if (resultSet.next()) {
                    // 用户存在，开始更新
                    String updateSql = "UPDATE users SET password=?, name=?, age=?, height=?, weight=?, gender=? WHERE phone=?";
                    updateStmt = connection.prepareStatement(updateSql);
                    updateStmt.setString(1,password);
                    updateStmt.setString(2, name);
                    updateStmt.setInt(3, age);
                    updateStmt.setFloat(4, height);
                    updateStmt.setFloat(5, weight);
                    updateStmt.setString(6, gender);
                    updateStmt.setString(7, phone);

                    int rowsAffected = updateStmt.executeUpdate();
                    return rowsAffected > 0;
                } else {
                    // 用户不存在
                    Log.e("UpdateUserTask", "用户不存在：" + phone);
                    return false;
                }

            } catch (Exception e) {
                Log.e("UpdateUserTask", "更新失败", e);
                return false;
            } finally {
                closeResources(connection, checkStmt, resultSet);
                closeResources(connection, updateStmt);
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                Toast.makeText(context, "保存成功", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "保存失败：用户不存在或网络异常", Toast.LENGTH_LONG).show();
            }
        }

        // 资源关闭方法
        private static void closeResources(Connection conn, PreparedStatement stmt, ResultSet rs) {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (stmt != null) stmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }

        private static void closeResources(Connection conn, PreparedStatement stmt) {
            closeResources(conn, stmt, null);
        }
    }

    public void updateUser(Context context, String phone, String password, String name, String age, String height, String weight, String gender) {
        new UpdateUserTask(context).execute(phone, password, name, age, height, weight, gender);
    }

    /**
     * 删除用户信息任务
     */
    private static class DeleteUserTask extends android.os.AsyncTask<String, Void, Boolean> {

        private Context context;
        private Exception exception;

        public DeleteUserTask(Context context) {
            this.context = context.getApplicationContext();
        }

        @Override
        protected Boolean doInBackground(String... params) {
            String phone = params[0];

            Connection connection = null;
            PreparedStatement statement = null;

            try {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                // 同样是定位phone
                String sql = "DELETE FROM users WHERE phone=?";
                statement = connection.prepareStatement(sql);
                statement.setString(1, phone);

                int rowsDeleted = statement.executeUpdate();
                return rowsDeleted > 0;

            } catch (Exception e) {
                exception = e;
                Log.e("DeleteUserTask", "删除失败", e);
                return false;
            } finally {
                closeResources(connection, statement);
            }
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Toast.makeText(context, "删除成功！", Toast.LENGTH_SHORT).show();
            } else {
                String errorMsg = exception != null ? exception.getMessage() : "未知错误";
                Toast.makeText(context, "删除失败：" + errorMsg, Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * 查询所有用户任务
     */
    private static class GetAllUsersTask extends android.os.AsyncTask<Void, Void, List<User>> {

        private Context context;
        private OnUsersLoadedListener listener;
        private Exception exception;

        public GetAllUsersTask(Context context, OnUsersLoadedListener listener) {
            this.context = context.getApplicationContext();
            this.listener = listener;
        }

        @Override
        protected List<User> doInBackground(Void... voids) {
            List<User> userList = new ArrayList<>();

            Connection connection = null;
            PreparedStatement statement = null;
            ResultSet resultSet = null;

            try {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

                String sql = "SELECT * FROM users";
                statement = connection.prepareStatement(sql);
                resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    String phone = resultSet.getString("phone");
                    String password = resultSet.getString("password");
                    String name = resultSet.getString("name");
                    int age = resultSet.getInt("age");
                    float height = resultSet.getFloat("height");
                    float weight = resultSet.getFloat("weight");
                    String gender = resultSet.getString("gender");

                    userList.add(new User(phone,password, name, age, height, weight, gender));
                }

                return userList;

            } catch (Exception e) {
                exception = e;
                Log.e("GetAllUsersTask", "查询失败", e);
                return null;
            } finally {
                closeResources(connection, statement, resultSet);
            }
        }

        @Override
        protected void onPostExecute(List<User> users) {
            if (users != null && !users.isEmpty()) {
                listener.onUsersLoaded(users);
            } else {
                String errorMsg = exception != null ? exception.getMessage() : "没有找到用户";
                Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * 通过phone查询所有数据
     *
     */
    public interface OnUserLoadedListener {
        void onUserLoaded(User user);
    }

    // GetUserByPhoneTask 异步任务
    public static class GetUserByPhoneTask extends AsyncTask<String, Void, User> {

        private Context context;
        private Exception exception;
        private OnUserLoadedListener listener;

        public GetUserByPhoneTask(Context context, OnUserLoadedListener listener) {
            this.context = context.getApplicationContext();
            this.listener = listener;
        }

        @Override
        protected User doInBackground(String... params) {
            String phone = params[0];

            Connection connection = null;
            PreparedStatement statement = null;
            ResultSet resultSet = null;

            try {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

                String sql = "SELECT * FROM users WHERE phone=?";
                statement = connection.prepareStatement(sql);
                statement.setString(1, phone);
                resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    String password = resultSet.getString("password");
                    String name = resultSet.getString("name");
                    int age = resultSet.getInt("age");
                    float height = resultSet.getFloat("height");
                    float weight = resultSet.getFloat("weight");
                    String gender = resultSet.getString("gender");

                    return new User(phone, password, name, age, height, weight, gender);
                }
                return null;

            } catch (Exception e) {
                exception = e;
                Log.e("GetUserByPhoneTask", "查询失败", e);
                return null;
            } finally {
                closeResources(connection, statement, resultSet);
            }
        }

        @Override
        protected void onPostExecute(User user) {
            if (user != null) {
                listener.onUserLoaded(user);
            } else {
                String errorMsg = exception != null ? exception.getMessage() : "未找到该用户";
                Toast.makeText(context, "查询失败：" + errorMsg, Toast.LENGTH_LONG).show();
            }
        }

        // 关闭资源的方法（根据你已有的 DatabaseHelper 补全）
        private static void closeResources(Connection conn, PreparedStatement stmt, ResultSet rs) {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (stmt != null) stmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }

        private static void closeResources(Connection conn, PreparedStatement stmt) {
            closeResources(conn, stmt, null);
        }
    }
    public void getUserByPhone(Context context, String phone, OnUserLoadedListener listener) {
        new GetUserByPhoneTask(context, listener).execute(phone);
    }
    // ──────────────── 工具方法 ────────────────

    private static void closeResources(Connection conn, PreparedStatement stmt) {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ignored) {}
    }

    private static void closeResources(Connection conn, PreparedStatement stmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ignored) {}
    }

    // ──────────────── 数据模型类 ────────────────

    public static class User {
        public String phone;
        public String password;
        public String name;
        public int age;
        public float height;
        public float weight;
        public String gender;

        public User(String phone, String password,String name, int age, float height, float weight, String gender) {
            this.phone = phone;
            this.password = password;
            this.name = name;
            this.age = age;
            this.height = height;
            this.weight = weight;
            this.gender = gender;
        }
        public String getPhone() {
            return phone;
        }

        public String getPassword() {
            return password;
        }

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        public float getHeight() {
            return height;
        }

        public float getWeight() {
            return weight;
        }

        public String getGender() {
            return gender;
        }

        // 可选：Setter 方法（如果你需要修改字段值）

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public void setHeight(float height) {
            this.height = height;
        }

        public void setWeight(float weight) {
            this.weight = weight;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }
    }

    // ──────────────── 回调接口 ────────────────

    public interface OnUsersLoadedListener {
        void onUsersLoaded(List<User> users);
    }
    private void closeResources(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ignored) {}
    }


}