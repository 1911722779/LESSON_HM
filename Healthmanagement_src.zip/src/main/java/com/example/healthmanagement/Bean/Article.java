package com.example.healthmanagement.Bean;

import java.io.Serializable;

public class Article implements Serializable {  // 实现 Serializable
    private int id;
    private String title;
    private String author;
    private int likes;
    private boolean isCollect;
    private String content;  // 新增字段

    public Article(int id, String title, String author, int likes, boolean isCollect, String content) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.likes = likes;
        this.isCollect = isCollect;
        this.content = content;
    }

    // Getter 方法
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getLikes() { return likes; }
    public boolean isCollect() { return isCollect; }
    public String getContent() { return content; }  // 新增 getter
    // Setter 方法
    public void setLikes(int likes) {
        this.likes = likes;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public void setCollect(boolean collect) {
        isCollect = collect;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setContent(String content) {
        this.content = content;
    }


}
