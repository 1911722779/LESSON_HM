package com.example.healthmanagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.healthmanagement.Fragment.HealthInputFragment;
import com.example.healthmanagement.Fragment.HomeFragment;
import com.example.healthmanagement.Fragment.ManageFragment;
import com.example.healthmanagement.Fragment.MyFragment;
import com.example.healthmanagement.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class FragmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_main);

        // 默认加载首页 Fragment
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragment_container, new HomeFragment())
                    .commit();
        }

        // 获取 BottomNavigationView
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        // 设置点击监听
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;

                int id = item.getItemId();
                if (id == R.id.nav_home) {
                    fragment = new HomeFragment();
                } else if (id == R.id.nav_checkin) {
                    fragment = new ManageFragment();
                } else if (id == R.id.nav_profile) {
                    fragment = new MyFragment();
                } else if (id == R.id.nav_read) {
                    fragment = new HealthInputFragment();
                }

                if (fragment != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, fragment)
                            .commit();
                }

                return true;
            }
        });
    }
}


