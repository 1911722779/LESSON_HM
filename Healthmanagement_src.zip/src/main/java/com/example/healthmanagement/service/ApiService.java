package com.example.healthmanagement.service;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {

    // 获取所有文章
    @GET("/api/articles")
    Call<List<com.example.healthmanagement.Bean.Article>> getAllArticles();

    // 搜索文章（标题或作者）
    @POST("/api/search")

    Call<List<com.example.healthmanagement.Bean.Article>> searchArticles(@Body Map<String, String> body);
}
