package com.example.healthmanagement;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthmanagement.Data.UserDatabaseHelper;

public class LoginActivity extends AppCompatActivity {

    private EditText phoneInput, passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 注册点击“去注册”的跳转
        TextView tvRegister = findViewById(R.id.tv_register);
        tvRegister.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // 初始化输入框
        phoneInput = findViewById(R.id.editTextPhone);
        passwordInput = findViewById(R.id.editTextTextPassword);

        // 登录按钮点击事件
        Button btnLogin = findViewById(R.id.btn_login);
        btnLogin.setOnClickListener(v -> {
            String phone = phoneInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (phone.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "请输入手机号和密码", Toast.LENGTH_SHORT).show();
            } else {
                new LoginTask().execute(phone, password);
            }
        });
    }

    private class LoginTask extends AsyncTask<String, Void, Boolean> {
        private String phone;

        @Override
        protected Boolean doInBackground(String... strings) {
            phone = strings[0];
            String password = strings[1];

            UserDatabaseHelper dbHelper = new UserDatabaseHelper(LoginActivity.this);
            return dbHelper.checkUser(phone, password); // 调用数据库验证
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                saveUserPhone(phone); // 保存手机号
                Toast.makeText(LoginActivity.this, "登录成功！", Toast.LENGTH_SHORT).show();

                // 跳转到主界面
                Intent intent = new Intent(LoginActivity.this, FragmentActivity.class);
                startActivity(intent);
                finish(); // 结束登录页面，防止回退回来
            } else {
                Toast.makeText(LoginActivity.this, "手机号或密码错误", Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * 将手机号保存到 SharedPreferences
     */
    private void saveUserPhone(String phone) {
        SharedPreferences sharedPref = getSharedPreferences("user_data", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("phone", phone);
        editor.apply();
    }
}