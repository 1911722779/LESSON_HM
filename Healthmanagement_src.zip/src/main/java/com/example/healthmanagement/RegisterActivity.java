package com.example.healthmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthmanagement.Data.UserDatabaseHelper;

public class RegisterActivity extends AppCompatActivity {

    private EditText etPhone,etPassword,etName,etAge,etHeight,etWeight;
    private RadioGroup rgGender;
    private UserDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // 初始化控件
        etPhone = findViewById(R.id.et_phone);
        etPassword = findViewById(R.id.et_password);
        etName = findViewById(R.id.et_name);
        etAge = findViewById(R.id.et_age);
        etHeight = findViewById(R.id.et_height);
        etWeight = findViewById(R.id.et_weight);
        rgGender = findViewById(R.id.rg_gender);

        // 初始化 DatabaseHelper
        dbHelper = new UserDatabaseHelper(this);

        // 注册按钮点击事件
        Button btnRegister = findViewById(R.id.btn_register);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // 获取用户信息
                String phone = etPhone.getText().toString();
                String password = etPassword.getText().toString();

                // 检查手机号和密码是否为空
                if (phone.isEmpty() || password.isEmpty()) {
                    // 提示用户必须填写手机号和密码
                    Toast.makeText(RegisterActivity.this, "请输入手机号和密码", Toast.LENGTH_SHORT).show();
                    return;  // 停止后续执行
                }
                if (phone.length() < 6) {
                    Toast.makeText(RegisterActivity.this, "请输入有效的手机号", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.length() < 6) {
                    Toast.makeText(RegisterActivity.this, "密码至少6位", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 获取用户信息（非必填字段），如果为空则使用默认值
                String name = etName.getText().toString().trim();
                if (name.isEmpty()) {
                    name = "";  // 可选：设置为空字符串
                }

                String ageStr = etAge.getText().toString().trim();
                int age = 0;
                if (!ageStr.isEmpty()) {
                    age = Integer.parseInt(ageStr);
                }

                String heightStr = etHeight.getText().toString().trim();
                float height = 0f;
                if (!heightStr.isEmpty()) {
                    height = Float.parseFloat(heightStr);
                }

                String weightStr = etWeight.getText().toString().trim();
                float weight = 0f;
                if (!weightStr.isEmpty()) {
                    weight = Float.parseFloat(weightStr);
                }
                // 获取性别
                int selectedId = rgGender.getCheckedRadioButtonId();
                if (selectedId == -1) {
                    Toast.makeText(RegisterActivity.this, "请选择性别", Toast.LENGTH_SHORT).show();
                    return;
                }
                RadioButton radioButton = findViewById(selectedId);
                String gender = radioButton.getText().toString();

                // 调用 DatabaseHelper 的 registerUser 方法进行注册

                dbHelper.registerUser(RegisterActivity.this, phone, password, name, age, height, weight, gender);
                Toast.makeText(RegisterActivity.this,"注册成功！", Toast.LENGTH_SHORT).show();
            }
        });

        // 返回登录页面点击事件
        TextView tvLogin = findViewById(R.id.tv_login);
        // 设置点击事件
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        });
    }

}
