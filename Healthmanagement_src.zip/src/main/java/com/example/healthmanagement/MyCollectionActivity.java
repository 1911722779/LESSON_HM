package com.example.healthmanagement;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthmanagement.Adapter.ArticleAdapter;
import com.example.healthmanagement.Data.ArticleDatabaseHelper;
import com.example.healthmanagement.R;
import com.example.healthmanagement.Bean.Article;

import java.util.List;

public class MyCollectionActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TextView tvEmpty;
    private ArticleAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_my_collection); // 布局是你提供的那个 LinearLayout

        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tv_empty);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 创建适配器并传入点击监听器
        adapter = new ArticleAdapter();
//        adapter = new ArticleAdapter();

        recyclerView.setAdapter(adapter);

        new LoadCollectionTask().execute();
    }

    private class LoadCollectionTask extends AsyncTask<Void, Void, List<Article>> {

        @Override
        protected List<Article> doInBackground(Void... voids) {
            return new ArticleDatabaseHelper().getCollectedArticles();
        }

        @Override
        protected void onPostExecute(List<Article> articles) {
            if (articles != null && !articles.isEmpty()) {
                adapter.updateData(articles);
                recyclerView.setVisibility(View.VISIBLE);
                tvEmpty.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                tvEmpty.setVisibility(View.VISIBLE);
            }
        }
    }
}