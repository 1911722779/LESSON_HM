package com.example.healthmanagement.Fragment;

import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.healthmanagement.Adapter.ArticleAdapter;
import com.example.healthmanagement.R;
import com.example.healthmanagement.Data.ArticleDatabaseHelper;
import com.example.healthmanagement.Bean.Article;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HomeFragment extends Fragment {

    private ViewPager2 viewPager2;
    private EditText editSearch;
    private RecyclerView recyclerView;
    private Button btnsearch;
    private ArticleAdapter adapter;
    private ArticleDatabaseHelper dbHelper;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 初始化控件
        viewPager2 = view.findViewById(R.id.viewPager);
        editSearch = view.findViewById(R.id.edit_search);
        recyclerView = view.findViewById(R.id.recycler_view);
        btnsearch = view.findViewById(R.id.btn_search);

        // 设置 Banner
        List<Integer> images = Arrays.asList(
                R.drawable.banner1,
                R.drawable.banner2,
                R.drawable.banner3
        );
        ImageSliderAdapter adapter2 = new ImageSliderAdapter(images);
        viewPager2.setAdapter(adapter2);

        // 自动轮播
        new android.os.Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            int currentPosition = 0;
            @Override
            public void run() {
                if (currentPosition == images.size()) currentPosition = 0;
                viewPager2.setCurrentItem(currentPosition++, true);
            }
        }, 2000);

        // 初始化数据库帮助类
        dbHelper = new ArticleDatabaseHelper();

        // 设置 RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new ArticleAdapter();
        recyclerView.setAdapter(adapter);

        // 加载所有文章
        loadAllArticles();

        // 设置搜索按钮点击事件
        btnsearch.setOnClickListener(v -> {
            String query = editSearch.getText().toString().trim();
            if (!query.isEmpty()) {
                searchArticles(query);
            } else {
                loadAllArticles();
                Toast.makeText(requireContext(), "请输入关键词进行搜索", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    // 加载所有文章
    private void loadAllArticles() {
        dbHelper.getAllArticles(articles -> {
            adapter.updateData(articles);
        });
    }
    // 搜索文章
    private void searchArticles(String query) {
        dbHelper.searchArticles(query, articles -> {
            if (articles != null && !articles.isEmpty()) {
                adapter.updateData(articles);
                Toast.makeText(requireContext(), "搜索成功，找到 " + articles.size() + " 条结果", Toast.LENGTH_SHORT).show();
            } else {
                adapter.updateData(new ArrayList<>()); // 清空列表
                Toast.makeText(requireContext(), "没有找到相关文章", Toast.LENGTH_SHORT).show();
            }
        });
    }
}