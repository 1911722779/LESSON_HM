package com.example.healthmanagement.Fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.healthmanagement.Data.UserDatabaseHelper;
import com.example.healthmanagement.LoginActivity;
import com.example.healthmanagement.MyCollectionActivity;
import com.example.healthmanagement.R;

public class PersonalInfoFragment extends Fragment {

    private String originalPhone;
    private EditText etPhone, etPassword, etName, etAge, etHeight, etWeight;
    private Spinner spGender;
    private Button btnSave, btnCancel;

    private SharedPreferences sharedPreferences;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadOriginalPhone();  // 加载保存的手机号
    }
    /**
     * 从 SharedPreferences 中加载原始手机号
     */
    private void loadOriginalPhone() {
        SharedPreferences sharedPref = requireContext().getSharedPreferences("user_phone", Context.MODE_PRIVATE);
        originalPhone = sharedPref.getString("phone", null);  // 获取键为 phone 的值

        if (originalPhone == null) {
            Toast.makeText(requireContext(), "未找到登录手机号，请重新登录", Toast.LENGTH_LONG).show();
            // 可选：跳转回登录页
            Intent intent = new Intent(requireContext(), LoginActivity.class);
            startActivity(intent);
            requireActivity().finish();
        }
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_personal_info, container, false);

        etPhone = view.findViewById(R.id.et_phone);
        etPassword = view.findViewById(R.id.et_password);
        etName = view.findViewById(R.id.et_name);
        etAge = view.findViewById(R.id.et_age);
        etHeight = view.findViewById(R.id.et_height);
        etWeight = view.findViewById(R.id.et_weight);
        spGender = view.findViewById(R.id.sp_gender);
        btnSave = view.findViewById(R.id.btn_save);
        btnCancel = view.findViewById(R.id.btn_cancel);

        // 获取 SharedPreferences
        sharedPreferences = requireActivity().getSharedPreferences("user_data", Context.MODE_PRIVATE);
        // 获取登录手机号
        String phone = sharedPreferences.getString("phone", "");

        // 加载用户数据
        loadUserInfo(originalPhone);

        // 设置保存按钮点击事件
        btnSave.setOnClickListener(v -> saveUserInfo(originalPhone));

        // 设置取消按钮点击事件
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        return view;
    }

    private void loadUserInfo(String phone) {
        // 从MySQL数据库加载用户数据并填充到EditText中
        new UserDatabaseHelper.GetUserByPhoneTask(requireContext(), user -> {
            if (user != null) {
                etPhone.setText(user.getPhone());
                etPassword.setText(user.getPassword());
                etName.setText(user.getName());
                etAge.setText(String.valueOf(user.getAge()));
                etHeight.setText(String.valueOf(user.getHeight()));
                etWeight.setText(String.valueOf(user.getWeight()));

                // 设置性别 Spinner（假设数组资源是 "male", "female"）
                if ("男".equals(user.getGender()) || "male".equals(user.getGender())) {
                    spGender.setSelection(0);
                } else {
                    spGender.setSelection(1);
                }

                // 密码可编辑
                etPhone.setEnabled(false); // 手机号不能改
                etPassword.setEnabled(true);
            }
        }).execute(phone);
    }


    private void saveUserInfo(String originalPhone) {
        // 获取EditText和Spinner中的数据
        String inputPhone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String name = etName.getText().toString().trim();
        String ageStr = etAge.getText().toString().trim();
        String heightStr = etHeight.getText().toString().trim();
        String weightStr = etWeight.getText().toString().trim();
        String gender = spGender.getSelectedItem().toString();

        // 校验：是否填写完整
        if (password.isEmpty() || name.isEmpty() || ageStr.isEmpty() || heightStr.isEmpty() || weightStr.isEmpty()) {
            Toast.makeText(requireContext(), "请填写完整信息", Toast.LENGTH_SHORT).show();
            return;
        }

        // 校验：电话号码是否一致
        if (!inputPhone.equals(originalPhone)) {
            Toast.makeText(requireContext(), "电话号码信息不正确，请重新输入", Toast.LENGTH_LONG).show();
            return;
        }

        // 转换数据类型
        int age = Integer.parseInt(ageStr);
        float height = Float.parseFloat(heightStr);
        float weight = Float.parseFloat(weightStr);

        // 执行异步任务更新数据库
        new UserDatabaseHelper.UpdateUserTask(requireContext()).execute(
                inputPhone, password, name, String.valueOf(age), String.valueOf(height), String.valueOf(weight), gender
        );
    }

    
}