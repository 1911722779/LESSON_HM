package com.example.healthmanagement.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.healthmanagement.HealthReportActivity;
import com.example.healthmanagement.R;

public class HealthInputFragment extends Fragment {

    private EditText etHeight, etWeight, etSystolic, etDiastolic, etBloodSugar;

    public HealthInputFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_health_input, container, false);

        // 初始化视图
        etHeight = view.findViewById(R.id.et_height);
        etWeight = view.findViewById(R.id.et_weight);
        etSystolic = view.findViewById(R.id.et_systolic);
        etDiastolic = view.findViewById(R.id.et_diastolic);
        etBloodSugar = view.findViewById(R.id.et_blood_sugar);

        Button btnGenerate = view.findViewById(R.id.btn_generate_report);

        btnGenerate.setOnClickListener(v -> generateAndNavigate());
        return view;
    }

    private void generateAndNavigate() {
        try {
            double height = Double.parseDouble(etHeight.getText().toString());
            double weight = Double.parseDouble(etWeight.getText().toString());
            int systolic = Integer.parseInt(etSystolic.getText().toString());
            int diastolic = Integer.parseInt(etDiastolic.getText().toString());
            double bloodSugar = Double.parseDouble(etBloodSugar.getText().toString());

            // 跳转到报表页面并传递数据
            Intent intent = new Intent(requireContext(), HealthReportActivity.class);
            intent.putExtra("height", height);
            intent.putExtra("weight", weight);
            intent.putExtra("systolic", systolic);
            intent.putExtra("diastolic", diastolic);
            intent.putExtra("blood_sugar", bloodSugar);
            startActivity(intent);

        } catch (NumberFormatException e) {
            Toast.makeText(requireContext(), "请输入有效的数字！", Toast.LENGTH_SHORT).show();
        }
    }
}
