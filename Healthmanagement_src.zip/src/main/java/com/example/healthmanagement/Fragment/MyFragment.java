package com.example.healthmanagement.Fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.healthmanagement.Data.ArticleDatabaseHelper;
import com.example.healthmanagement.MyCollectionActivity;
import com.example.healthmanagement.R;

public class MyFragment extends Fragment {

    private TextView tvUsername;
    private TextView tvPersonalInfo;
    private TextView tvMyCollection;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my, container, false);

        tvUsername = view.findViewById(R.id.tv_username);
        tvPersonalInfo = view.findViewById(R.id.tv_personal_info);
        tvMyCollection = view.findViewById(R.id.tv_my_collection);

        // 设置用户名
        SharedPreferences sharedPref = getActivity().getSharedPreferences("user_data", Context.MODE_PRIVATE);
        String phone = sharedPref.getString("phone", "未登录"); // 默认值是“未登录”
        tvUsername.setText(phone);

        // 加载收藏数量
//        new LoadCollectionCountTask().execute();

        // 设置点击事件 - 个人信息
        tvPersonalInfo.setOnClickListener(v -> {
            PersonalInfoFragment personalInfoFragment = new PersonalInfoFragment();
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, personalInfoFragment)
                    .addToBackStack(null)
                    .commit();
        });

        // 设置点击事件 - 我的收藏
        tvMyCollection.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), MyCollectionActivity.class);
            startActivity(intent);
        });

        return view;
    }

}